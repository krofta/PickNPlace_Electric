#ifndef __LED2_CONFIG_H
#define __LED2_CONFIG_H

/* no configuration supported yet */

#endif /* __LED2_CONFIG_H */
