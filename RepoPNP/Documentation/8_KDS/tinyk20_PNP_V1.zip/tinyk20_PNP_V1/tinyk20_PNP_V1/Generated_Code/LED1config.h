#ifndef __LED1_CONFIG_H
#define __LED1_CONFIG_H

/* no configuration supported yet */

#endif /* __LED1_CONFIG_H */
